/*Jacob Shanefield Fall 2017*/
$(document).ready(function()
 {
	function date()
	{
		//put date in footer
		 document.write(Date());
	 }
 });